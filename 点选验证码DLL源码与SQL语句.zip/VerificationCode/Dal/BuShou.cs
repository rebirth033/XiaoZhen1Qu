﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;

namespace VerificationCode.Dal
{
    public class BuShou
    {
        private readonly DBHelper _dbHelper = new DBHelper();
        /// <summary>
        /// 构造函数
        /// </summary>
        public BuShou()
        {
        }
        /// <summary>
        /// 添加记录
        /// </summary>
        /// <param name="model">VerificationCode.Model.BuShou实体类</param>
        /// <returns>新增记录的ID</returns>
        public int Add(VerificationCode.Model.BuShou model)
        {
            if (Get(model.Code) == null)
            {
                string sql = @"INSERT INTO bushou
				(Code,Text) 
				VALUES(@Code,@Text);
				SELECT LAST_INSERT_ID();";
                MySqlParameter[] parameters = new MySqlParameter[]{
                model.Code == null ? new MySqlParameter("@Code", MySqlDbType.VarChar, 255) { Value = DBNull.Value } : new MySqlParameter("@Code", MySqlDbType.VarChar, 255) { Value = model.Code },
                model.Text == null ? new MySqlParameter("@Text", MySqlDbType.VarChar, 255) { Value = DBNull.Value } : new MySqlParameter("@Text", MySqlDbType.VarChar, 255) { Value = model.Text }
            };
                int maxID;
                return int.TryParse(_dbHelper.ExecuteScalar(sql, parameters), out maxID) ? maxID : -1;
            }
            return 0;
        }

        /// <summary>
        /// 更新记录
        /// </summary>
        /// <param name="model">VerificationCode.Model.BuShou实体类</param>
        public int Update(VerificationCode.Model.BuShou model)
        {
            string sql = @"UPDATE bushou SET 
				Code=@Code,Text=@Text
				WHERE ID=@ID";
            MySqlParameter[] parameters = new MySqlParameter[]{
                model.Code == null ? new MySqlParameter("@Code", MySqlDbType.VarChar, 255) { Value = DBNull.Value } : new MySqlParameter("@Code", MySqlDbType.VarChar, 255) { Value = model.Code },
                model.Text == null ? new MySqlParameter("@Text", MySqlDbType.VarChar, 255) { Value = DBNull.Value } : new MySqlParameter("@Text", MySqlDbType.VarChar, 255) { Value = model.Text },
                new MySqlParameter("@ID", MySqlDbType.Int32, 11){ Value = model.ID }
            };
            return _dbHelper.Execute(sql, parameters);
        }
        /// <summary>
        /// 删除记录
        /// </summary>
        public int Delete(int id)
        {
            string sql = "DELETE FROM bushou WHERE ID=@ID";
            MySqlParameter[] parameters = new MySqlParameter[]{
                new MySqlParameter("@ID", MySqlDbType.Int32, 11){ Value = id }
            };
            return _dbHelper.Execute(sql, parameters);
        }
        /// <summary>
        /// 将DataRedar转换为List
        /// </summary>
        private List<VerificationCode.Model.BuShou> DataReaderToList(MySqlDataReader dataReader)
        {
            List<VerificationCode.Model.BuShou> List = new List<VerificationCode.Model.BuShou>();
            VerificationCode.Model.BuShou model = null;
            while (dataReader.Read())
            {
                model = new VerificationCode.Model.BuShou();
                model.ID = dataReader.GetInt32(0);
                if (!dataReader.IsDBNull(1))
                    model.Code = dataReader.GetString(1);
                if (!dataReader.IsDBNull(2))
                    model.Text = dataReader.GetString(2);
                List.Add(model);
            }
            return List;
        }
        /// <summary>
        /// 查询所有记录
        /// </summary>
        public List<VerificationCode.Model.BuShou> GetAll()
        {
            string sql = "SELECT * FROM bushou";
            MySqlDataReader dataReader = _dbHelper.GetDataReader(sql);
            List<VerificationCode.Model.BuShou> List = DataReaderToList(dataReader);
            dataReader.Close();
            return List;
        }
        /// <summary>
        /// 查询记录数
        /// </summary>
        public long GetCount()
        {
            string sql = "SELECT COUNT(*) FROM bushou";
            long count;
            return long.TryParse(_dbHelper.GetFieldValue(sql), out count) ? count : 0;
        }
        /// <summary>
        /// 根据主键查询一条记录
        /// </summary>
        public VerificationCode.Model.BuShou Get(int id)
        {
            string sql = "SELECT * FROM bushou WHERE ID=@ID";
            MySqlParameter[] parameters = new MySqlParameter[]{
                new MySqlParameter("@ID", MySqlDbType.Int32, 11){ Value = id }
            };
            MySqlDataReader dataReader = _dbHelper.GetDataReader(sql, parameters);
            List<VerificationCode.Model.BuShou> List = DataReaderToList(dataReader);
            dataReader.Close();
            return List.Count > 0 ? List[0] : null;
        }

        /// <summary>
        /// 根据主键查询一条记录
        /// </summary>
        public VerificationCode.Model.BuShou Get(string id)
        {
            string sql = "SELECT * FROM bushou WHERE Code=@ID";
            MySqlParameter[] parameters = new MySqlParameter[]{
                new MySqlParameter("@ID", MySqlDbType.VarChar, 11){ Value = id }
            };
            MySqlDataReader dataReader = _dbHelper.GetDataReader(sql, parameters);
            List<VerificationCode.Model.BuShou> List = DataReaderToList(dataReader);
            dataReader.Close();
            return List.Count > 0 ? List[0] : null;
        }
    }
}
