﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace VerificationCode.Model
{
    public class Code
    {
        public string Id { get; set; }
        public string AnswerValue { get; set;}

        public string CodeImg { get; set; }

        public List<Answer> Answer { get; set; }
    }
}
