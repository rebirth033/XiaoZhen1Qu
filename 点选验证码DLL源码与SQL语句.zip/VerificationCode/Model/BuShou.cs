﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace VerificationCode.Model
{
    [Serializable]
    public class BuShou
    {
      
            /// <summary>
            /// ID
            /// </summary>
            [DisplayName("ID")]
            public int ID { get; set; }

            /// <summary>
            /// Code
            /// </summary>
            [DisplayName("Code")]
            public string Code { get; set; }

            /// <summary>
            /// Text
            /// </summary>
            [DisplayName("Text")]
            public string Text { get; set; }

       
    }
}
