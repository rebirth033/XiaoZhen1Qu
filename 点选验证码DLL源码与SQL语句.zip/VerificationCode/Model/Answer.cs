﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net.Mime;
using System.Text;

namespace VerificationCode.Model
{
    public class Answer
    {
        public string Id { get; set; }
       //public string Value { get; set; }
        public string Img { get; set; }
    }
}
