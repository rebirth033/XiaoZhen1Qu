﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VerificationCode
{
   public class Config
   {
        /// <summary>
        /// 数据库连接字符串
        /// </summary>
       public static string ConectionString= "Server=localhost;Database=VerificationCode;Uid=root;Pwd=123456;Allow User Variables=True";
   }
}
