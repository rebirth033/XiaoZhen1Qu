﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using HtmlAgilityPack;

namespace VerificationCode
{
    public class CreateDictionary
    {
        private const string MessageNameXPath = "//ul[starts-with(@class,'bs_list')]";
        public static void GetHtml(string url)
        {

            var myWebClient = new WebClient();
            var myStream = myWebClient.OpenRead(url);
            GetMessage(myStream); //这里调用的是下面的方法
            if (myStream != null) myStream.Close();

        }

        private static void GetMessage(Stream myStream)
        {
            var document = new HtmlDocument();
            document.Load(myStream, Encoding.UTF8);
            var rootNode = document.DocumentNode;
            var messageNodeList = rootNode.SelectNodes(MessageNameXPath);
             VerificationCode.Dal.BuShou bs=new Dal.BuShou();
            VerificationCode.Dal.WenZhi wz = new Dal.WenZhi();
            List<VerificationCode.Model.BuShou> text = bs.GetAll();
            /*foreach (var item in messageNodeList)
            {
                var li = item.SelectNodes("//li/a");
                foreach (var i in li)
                {
                    bs.Add(new Model.BuShou() { Code = i.GetAttributeValue("href", "").Replace("bs", ""), Text = i.InnerText });
                    text.Add(new BuShou() { Value = i.InnerText, Code = i.GetAttributeValue("href", "").Replace("bs", "") });
                }

            }*/
            var doc = new HtmlDocument();
            foreach (var item in text)
            {
                
                 var myWebClient = new WebClient();
                Stream stream;
                try
                {
                    stream = myWebClient.OpenRead("http://www.hanzizidian.com/bs" + item.Code);
                    doc.Load(stream, Encoding.UTF8);
                    var rootdoc = doc.DocumentNode;
                    var wenzhiList = rootdoc.SelectNodes("//div[starts-with(@class,'bs')]/li/a");

                   /* foreach (var t in wenzhiList)
                    {

                        var li = t.SelectNodes("/li/a");*/
                        foreach (var i in wenzhiList)
                        {
                            wz.Add(new Model.WenZhi() { BuShouCode = item.Code, Text = i.InnerText, Code = i.GetAttributeValue("href", "").Replace("bs", "") });
                            // wz_list.Add(new WenZhi { Value = i.InnerText, Code = i.GetAttributeValue("href", "").Replace("bs", "") });
                        }

                  /*  }*/

                    if (myStream != null) myStream.Close();
                }
                catch (Exception e)
                {
                   
                   continue;
                }
                
               


            }
            //File.Create("E:\\Department.xml");
          /*  XmlSerializer serializer = new XmlSerializer(text.GetType());
            TextWriter writer = new StreamWriter("E:\\Dictionary.xml");
            serializer.Serialize(writer, text);
            writer.Close();*/

         }

        public class BuShou
        {

            [XmlAttribute]
            public string Code { get; set; }

            [XmlAttribute]
            public string Value { get; set; }

            public List<WenZhi> WenZhi { get; set; }

        }

        public class WenZhi
        {

            [XmlAttribute]
            public string Code { get; set; }

            public string Value { get; set; }

        }


    }
}
