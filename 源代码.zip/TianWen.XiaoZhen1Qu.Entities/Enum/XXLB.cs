﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TianWen.XiaoZhen1Qu.Entities.Enum
{
    public enum XXLBMJ
    {
        系统通知 = 0,
        客户咨询 = 1,
        我的咨询 = 2
    }
}
