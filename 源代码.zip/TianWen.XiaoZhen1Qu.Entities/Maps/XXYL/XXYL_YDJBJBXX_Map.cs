﻿using FluentNHibernate.Mapping;
using TianWen.XiaoZhen1Qu.Entities.Models;

namespace TianWen.XiaoZhen1Qu.Entities.Maps
{
    public class XXYL_YDJBJBXX_Map : ClassMap<XXYL_YDJBJBXX>
    {
        public XXYL_YDJBJBXX_Map()
        {
            Table("XXYL_YDJBJBXX");
            #region 属性
            Id(x => x.XXYL_YDJBJBXXID, "XXYL_YDJBJBXXID").GeneratedBy.Assigned().CustomType("AnsiString");
            Map(x => x.JCXXID, "JCXXID");
            Map(x => x.LB, "LB");
            Map(x => x.BCMS, "BCMS");
            Map(x => x.QY, "QY");
            Map(x => x.DD, "DD");
            Map(x => x.JTDZ, "JTDZ");
            #endregion

            #region OneToMany

            #endregion

            #region ManyToOne

            #endregion

        }
    }
}
