﻿using FluentNHibernate.Mapping;
using TianWen.XiaoZhen1Qu.Entities.Models;

namespace TianWen.XiaoZhen1Qu.Entities.Maps
{
    public class XXYL_XYWQJBXX_Map : ClassMap<XXYL_XYWQJBXX>
    {
        public XXYL_XYWQJBXX_Map()
        {
            Table("XXYL_XYWQJBXX");
            #region 属性
            Id(x => x.XXYL_XYWQJBXXID, "XXYL_XYWQJBXXID").GeneratedBy.Assigned().CustomType("AnsiString");
            Map(x => x.JCXXID, "JCXXID");
            Map(x => x.BCMS, "BCMS");
            Map(x => x.QY, "QY");
            Map(x => x.DD, "DD");
            Map(x => x.JTDZ, "JTDZ");
            #endregion

            #region OneToMany

            #endregion

            #region ManyToOne

            #endregion

        }
    }
}
