﻿using FluentNHibernate.Mapping;
using TianWen.XiaoZhen1Qu.Entities.Models;

namespace TianWen.XiaoZhen1Qu.Entities.Maps
{
    public class JYPX_YMJBXX_Map : ClassMap<JYPX_YMJBXX>
    {
        public JYPX_YMJBXX_Map()
        {
            Table("JYPX_YMJBXX");
            #region 属性
            Id(x => x.JYPX_YMJBXXID, "JYPX_YMJBXXID").GeneratedBy.Assigned().CustomType("AnsiString");
            Map(x => x.JCXXID, "JCXXID");
            Map(x => x.GJ, "GJ");
            Map(x => x.YMLB, "YMLB");
            Map(x => x.FWQY, "FWQY");
            Map(x => x.QY, "QY");
            Map(x => x.DD, "DD");
            Map(x => x.JTDZ, "JTDZ");
            Map(x => x.BCMS, "BCMS");
            #endregion

            #region OneToMany

            #endregion

            #region ManyToOne

            #endregion

        }
    }
}
