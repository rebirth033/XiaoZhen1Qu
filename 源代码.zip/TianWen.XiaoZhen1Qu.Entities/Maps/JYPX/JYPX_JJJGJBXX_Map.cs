﻿using FluentNHibernate.Mapping;
using TianWen.XiaoZhen1Qu.Entities.Models;

namespace TianWen.XiaoZhen1Qu.Entities.Maps
{
    public class JYPX_JJJGJBXX_Map : ClassMap<JYPX_JJJGJBXX>
    {
        public JYPX_JJJGJBXX_Map()
        {
            Table("JYPX_JJJGJBXX");
            #region 属性
            Id(x => x.JYPX_JJJGJBXXID, "JYPX_JJJGJBXXID").GeneratedBy.Assigned().CustomType("AnsiString");
            Map(x => x.JCXXID, "JCXXID");
            Map(x => x.SF, "SF");
            Map(x => x.FDJD, "FDJD");
            Map(x => x.FDKM, "FDKM");
            Map(x => x.FWQY, "FWQY");
            Map(x => x.QY, "QY");
            Map(x => x.DD, "DD");
            Map(x => x.JTDZ, "JTDZ");
            Map(x => x.BCMS, "BCMS");
            #endregion

            #region OneToMany

            #endregion

            #region ManyToOne

            #endregion

        }
    }
}
